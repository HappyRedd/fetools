/*
	This file has no contents.
	If you are looking for the unminified version of jquery.mmenu.min.js,
	it is a combination of these files:
		- jquery.mmenu.oncanvas.js
		- addons/offcanvas/jquery.mmenu.offcanvas.js
		- addons/scrollbugfix/jquery.mmenu.scrollbugfix.js
*/
console.group( 'jquery.mmenu.js has no contents.' );
console.error( 'If you are looking for the unminified version of jquery.mmenu.min.js, it is a combination of the files js/jquery.mmenu.oncanvas.js, addons/offcanvas/jquery.mmenu.offcanvas.js and addons/scrollbugfix/jquery.mmenu.scrollbugfix.js' );
console.groupEnd();